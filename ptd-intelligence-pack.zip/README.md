# PTD Intelligence Pack (n8n + Supabase + Meta CAPI)

This bundle contains:
- **meta-conversion-api/**: a minimal, production-ready Conversions API server (AED defaults)
- **n8n/flows/**: three import-ready workflows
- **supabase/sql/**: schema, rpc functions, and basic RLS
- **lovable/prompts/**: copy/paste prompts to build your UI in Lovable
- **postman_collection.json**: quick testing

## Quick Start

1. Deploy `meta-conversion-api` (Railway, Fly.io, Render, Vercel functions, or Docker).
2. Configure `.env` (see `.env.example`). Use your Pixel ID and long-lived access token.
3. In n8n, import all files from `n8n/flows/`. Set environment variables in n8n:
   - META_PIXEL_ID, META_ACCESS_TOKEN, TEST_EVENT_CODE, SUPABASE_URL, SUPABASE_ANON_KEY, TELEGRAM_TOKEN, TELEGRAM_CHAT_ID
4. In Supabase SQL editor, run files under `supabase/sql/` in order: `schema.sql` → `rpc.sql` → `rls.sql`.
5. (Optional) In Lovable, use prompts from `lovable/prompts/` to generate the dashboard.

## Endpoints
- `GET /health`
- `POST /api/events`
- `POST /api/events/purchase`
- `POST /api/events/batch`

## Notes
- Phone normalization uses UAE format by default (971…).
- Event batching respects Meta limits.
- Use Stape sGTM and your domain for fbp/fbc enrichment where available.
