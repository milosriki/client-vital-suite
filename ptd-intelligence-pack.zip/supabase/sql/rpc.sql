-- calculate daily health scores (dummy for demo)
create or replace function public.calculate_daily_health_scores()
returns void
language plpgsql
security definer
as $$
begin
  -- Example: mark all clients as green with low risk
  insert into health_scores (client_id, risk_score, as_of, color, details)
  select c.id, 0.1, current_date, 'green', jsonb_build_object('source','auto')
  from clients c
  on conflict (client_id, as_of) do update set
    risk_score = excluded.risk_score,
    color = excluded.color,
    details = excluded.details;
end;
$$;

-- review snapshot
create or replace function public.monthly_coach_review(p_coach text)
returns jsonb
language plpgsql
security definer
as $$
declare
  result jsonb;
begin
  select jsonb_build_object(
    'total_clients', count(*),
    'greens',  (select count(*) from health_scores where color='green' and as_of=current_date),
    'yellows', (select count(*) from health_scores where color='yellow' and as_of=current_date),
    'reds',    (select count(*) from health_scores where color='red' and as_of=current_date)
  )
  into result
  from clients;
  return result;
end;
$$;
