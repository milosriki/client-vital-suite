-- Tables
create table if not exists clients (
  id uuid primary key default gen_random_uuid(),
  email text unique,
  phone text,
  first_name text,
  last_name text,
  created_at timestamptz default now()
);

create table if not exists ad_events (
  id bigint generated always as identity primary key,
  event_name text not null,
  event_time timestamptz not null default now(),
  external_id text,
  event_id text,
  currency text,
  value numeric,
  raw jsonb,
  created_at timestamptz default now()
);
create index if not exists ad_events_event_time_idx on ad_events (event_time desc);

create table if not exists health_scores (
  id bigint generated always as identity primary key,
  client_id uuid references clients(id) on delete cascade,
  risk_score numeric not null,
  as_of date not null,
  color text,
  details jsonb,
  created_at timestamptz default now(),
  unique (client_id, as_of)
);

create table if not exists coach_reviews (
  id bigint generated always as identity primary key,
  coach text,
  period_month int,
  period_year int,
  summary jsonb,
  created_at timestamptz default now(),
  unique (coach, period_month, period_year)
);
