-- Enable RLS
alter table clients enable row level security;
alter table ad_events enable row level security;
alter table health_scores enable row level security;
alter table coach_reviews enable row level security;

-- Public read, service role write (example policies)
create policy if not exists "anon-read-clients" on clients for select using (true);
create policy if not exists "service-write-clients" on clients for insert with check (true);

create policy if not exists "anon-read-scores" on health_scores for select using (true);
create policy if not exists "service-write-scores" on health_scores for insert with check (true);
