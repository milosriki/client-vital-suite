import express from 'express';
import rateLimit from 'express-rate-limit';
import morgan from 'morgan';
import fetch from 'node-fetch';
import { v4 as uuidv4 } from 'uuid';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(morgan('tiny'));

const PORT = process.env.PORT || 3000;
const PIXEL_ID = process.env.META_PIXEL_ID;
const ACCESS_TOKEN = process.env.META_ACCESS_TOKEN;
const TEST_EVENT_CODE = process.env.TEST_EVENT_CODE || '';
const ACTION_SOURCE = process.env.DEFAULT_ACTION_SOURCE || 'website';

const limiter = rateLimit({ windowMs: 60 * 1000, max: 300 });
app.use(limiter);

const graphUrl = (path) => `https://graph.facebook.com/v20.0${path}`;

function normalizeUserData(ud = {}) {
  const lower = (s) => (typeof s === 'string' ? s.trim().toLowerCase() : undefined);
  const strip = (s) => (typeof s === 'string' ? s.replace(/[^0-9]/g, '') : undefined);
  return {
    emails: ud.emails?.map(lower).filter(Boolean),
    phones: ud.phones?.map((p)=> {
      let n = strip(p);
      if (!n) return undefined;
      if (n.startsWith('0')) n = `971${n.slice(1)}`;
      if (n.startsWith('971') === false && n.startsWith('00') === false && n.startsWith('+') === false) n = `971${n}`;
      return n;
    }).filter(Boolean),
    first_names: ud.first_names?.map(lower).filter(Boolean),
    last_names: ud.last_names?.map(lower).filter(Boolean),
    cities: ud.cities?.map(lower).filter(Boolean),
    states: ud.states?.map(lower).filter(Boolean),
    countries: ud.countries?.map((c)=> lower(c)).filter(Boolean),
    external_ids: ud.external_ids,
    client_ip_address: ud.client_ip_address,
    client_user_agent: ud.client_user_agent,
    fbp: ud.fbp,
    fbc: ud.fbc
  };
}

async function sendEvents(events, testCode) {
  const payload = { data: events };
  if (testCode) payload.test_event_code = testCode;
  const url = graphUrl(`/${PIXEL_ID}/events?access_token=${ACCESS_TOKEN}`);
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const json = await res.json();
  if (!res.ok) {
    const err = new Error(`Meta API error ${res.status}`);
    err.details = json;
    throw err;
  }
  return json;
}

app.get('/health', (req,res)=> res.json({ ok:true, time: new Date().toISOString() }));

// generic event
app.post('/api/events', async (req, res) => {
  try {
    const { event_name, event_time, user_data, custom_data, event_id, action_source, event_source_url, test } = req.body;
    const ed = {
      event_name,
      event_time: event_time || Math.floor(Date.now()/1000),
      event_id: event_id || uuidv4(),
      action_source: action_source || ACTION_SOURCE,
      event_source_url,
      user_data: normalizeUserData(user_data),
      custom_data
    };
    const out = await sendEvents([ed], test ? TEST_EVENT_CODE : '');
    res.json(out);
  } catch (e) {
    console.error('Error /api/events', e.details || e.message);
    res.status(400).json({ error: e.message, details: e.details });
  }
});

// purchase shortcut
app.post('/api/events/purchase', async (req,res)=> {
  try {
    const { value, currency='AED', userData={}, contentName, contentIds=[], orderId, event_time } = req.body;
    const event = {
      event_name: 'Purchase',
      event_time: event_time || Math.floor(Date.now()/1000),
      user_data: normalizeUserData(userData),
      custom_data: {
        currency, value, order_id: orderId, content_name: contentName, content_ids: contentIds
      },
      event_id: uuidv4(),
      action_source: ACTION_SOURCE
    };
    const out = await sendEvents([event], req.query.test ? TEST_EVENT_CODE : '');
    res.json(out);
  } catch(e) {
    console.error(e);
    res.status(400).json({ error: e.message, details: e.details });
  }
});

// batch
app.post('/api/events/batch', async (req,res)=> {
  try {
    const { events = [], test=false } = req.body;
    const normalized = events.map((e)=> ({
      ...e,
      event_time: e.event_time || Math.floor(Date.now()/1000),
      event_id: e.event_id || uuidv4(),
      action_source: e.action_source || ACTION_SOURCE,
      user_data: normalizeUserData(e.user_data || {})
    })).slice(0, 500); // Meta max
    const out = await sendEvents(normalized, test ? TEST_EVENT_CODE : '');
    res.json(out);
  } catch(e) {
    res.status(400).json({ error: e.message, details: e.details });
  }
});

app.listen(PORT, ()=> console.log(`PTD CAPI server listening on :${PORT}`));
